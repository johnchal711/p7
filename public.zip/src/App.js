import React from 'react';
import logo from './logo.svg';
import './App.css';

//https://gist.github.com/DriftwoodJP/b0bfbdd594161ee7f43b3c5f5a22fb22


function App() {

       
  return (

  // One-shot position request.


    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.

        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}
         
export default App;
